package com.studentapp.cucumber.steps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Managed;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.concurrent.TimeUnit;

public class ReproduceHWSteps {

    @Managed WebDriver driver;

    @Test

    @Given("^Student navigates to mixcloud website$")
    public void student_navigates_to_mixcloud_website() throws Throwable {
        driver.get("https://www.mixcloud.com/");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
    }

    @When("^Student clicks on the login button at home page$")
    public void student_clicks_on_the_login_button_at_home_page() throws Throwable {
        driver.findElement(By.xpath("//p[contains(text(),'Login')]")).click();

    }

    @When("^Student enters a valid email/username \"([^\"]*)\"$")
    public void student_enters_a_valid_email_username(String username) throws Throwable {
        driver.findElement(By.id("email")).sendKeys(username);

    }

    @When("^Student enters a valid password \"([^\"]*)\"$")
    public void student_enters_a_valid_password(String password) throws Throwable {
        driver.findElement(By.id("password")).sendKeys(password);

    }

    @When("^Student clicks on the login button$")
    public void student_clicks_on_the_login_button() throws Throwable {
        driver.findElement(By.xpath("//span[contains(text(),'Log In')]")).click();
        Thread.sleep(3000);

    }

    @Then("^Student find search field and enters Martin Garrix artist name$")
    public void student_find_search_field_and_enters_Martin_Garrix_artist_name() throws Throwable {
        driver.findElement(By.xpath("//body/div[@id='react-root']/div[1]/section[1]/div[3]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/input[1]")).click();
        driver.findElement(By.xpath("//body/div[@id='react-root']/div[1]/section[1]/div[3]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/input[1]")).sendKeys("Martin Garrix");


    }

    @Then("^At the right side bar find Martin Garrix icon and click of them$")
    public void at_the_right_side_bar_find_Martin_Garrix_icon_and_click_of_them() throws Throwable {
        driver.findElement(By.xpath("//body/div[@id='react-root']/div[1]/section[1]/div[3]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[3]/div[2]/div[1]/div[1]/div[1]/div[1]/span[1]/a[1]/div[1]/img[1]")).click();
        Thread.sleep(3000);

    }

    @Then("^Adding 'The Martin Garrix Show #(\\d+)' into you favourite \\(click on like icon\\)$")
    public void adding_The_Martin_Garrix_Show_into_you_favourite_click_on_like_icon(int arg1) throws Throwable {
        driver.findElement(By.xpath("//body/div[@id='react-root']/div[1]/section[1]/div[3]/div[1]/div[1]/div[3]/div[1]/div[3]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/*[1]")).click();
        Thread.sleep(3000);


    }

    @When("^Return into Your profile$")
    public void return_into_Your_profile() throws Throwable {
        driver.findElement(By.xpath("//body/div[@id='react-root']/div[1]/section[1]/div[3]/div[1]/div[1]/div[2]/div[1]/div[3]/div[3]/div[1]/div[1]/img[1]")).click();
        driver.findElement(By.xpath("//p[contains(text(),'Your profile')]")).click();
    }


    @When("^'The Martin Garrix Show #(\\d+)' should be added in favourites$")
    public void the_Martin_Garrix_Show_should_be_added_in_favourites(int arg1) throws Throwable {
        Thread.sleep(3000);
        WebElement artist = driver.findElement(By.xpath("//a[contains(text(),'The Martin Garrix Show #343')]"));
        Assert.assertEquals(true,artist.isDisplayed());

    }

    @When("^Deleting 'The Martin Garrix Show #(\\d+)' from favourites$")
    public void deleting_The_Martin_Garrix_Show_from_favourites(int arg1) throws Throwable {
        driver.findElement(By.xpath("//body/div[@id='react-root']/div[1]/section[1]/div[3]/div[1]/div[1]/div[3]/div[1]/div[3]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/span[1]")).click();
        Thread.sleep(3000);


        driver.quit();


    }


}
